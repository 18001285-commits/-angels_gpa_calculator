# CALCULATE YOUR GPA ACCURATELY

A Pen created on CodePen.

Original URL: [https://codepen.io/Angel-Mendez-the-sasster/pen/ogYJpBK](https://codepen.io/Angel-Mendez-the-sasster/pen/ogYJpBK).

